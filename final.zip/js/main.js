
jQuery(document).ready(function($){
  $('.slider-hero').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    dots:true
  });
});

jQuery(document).ready(function($){
  $('.slider-horizontal').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    dots:true
  });
});

jQuery(document).ready(function($){
  $('.slider-stuff').slick({
    slidesToShow: 4,
    slidesToScroll: 4,
    dots:true
  });
});
/*$('.filtering').slick({

});

var filtered = false;

$('.js-filter').on('click', function(){
  if (filtered === false) {
    $('.filtering').slick('slickFilter',':even');
    $(this).text('Unfilter Slides');
    filtered = true;
  } else {
    $('.filtering').slick('slickUnfilter');
    $(this).text('Filter Slides');
    filtered = false;
  }
});*/
